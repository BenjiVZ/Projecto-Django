# Django

A Django starter template as per the docs: https://docs.djangoproject.com/en/5.0/intro/tutorial01/

admin
123admin..